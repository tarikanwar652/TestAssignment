package Tarique.problem_codes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.JsonPath;
import com.jayway.restassured.response.Response;


public class MockableDemoTest {
	
	public CommonApiMethodCalls commonApiMethodCalls=new CommonApiMethodCalls();
	public String endpoint="http://demo4032024.mockable.io/apitest";
    private Logger logger = LoggerFactory.getLogger(this.getClass());	
	
	@Test
	public void getDataFromUrl(){
        Response response = commonApiMethodCalls.getDataFromUrl(endpoint);
        logger.info(response.getBody().asString()); //Logger will be used here 
  
        //assert response code
        assertResponseCode(response);
        
        //assert Header
        assertHeader(response);
        
		//using jsonPath [can move this to either main class or a common parsing util)
        com.jayway.restassured.path.json.JsonPath jsonPathEvaluator = response.jsonPath();
		ArrayList<HashMap> employeeData = jsonPathEvaluator.getJsonObject("employeeData");
       
		//assert Response body
        assertResponseWithData1(jsonPathEvaluator,employeeData);  
        
        //Calling assertion 4 from here
        assertResponseWithData2(employeeData);
	}
		
	
	
	
	
	// Assertions (can use a different class for assertion methods)
	public void assertResponseCode(Response response){
		Assert.assertEquals(response.getStatusCode(),200, "response code does not match");
		 logger.info("Assertion1:pass");
	}
	
	
	public void assertHeader( Response response ){
        Assert.assertTrue(response.getHeader("Content-Type").contains("application/json"),"header is not of json type");
        logger.info("Assertion2:pass");
	}
	
	public void assertResponseWithData1(com.jayway.restassured.path.json.JsonPath jsonPathEvaluator,ArrayList<HashMap> employeeData ){
		try{
		
			Assert.assertEquals(jsonPathEvaluator.get("status"), 200, "status code does not match");
			Assert.assertEquals(jsonPathEvaluator.get("message"), "data retrieved successful", "message does not match");
			
			Assert.assertEquals(employeeData.get(0).get("age"), 25, "age does not match");
			Assert.assertEquals(employeeData.get(0).get("role"), "QA Automation Developer", "role does not match");
			Assert.assertEquals(employeeData.get(0).get("dob"), "25-02-1994", "dob does not match");
	        logger.info("Assertion3:pass");
	        
		} catch (Exception e) {
			logger.info("error in parsing the response");
		}	
		
	}
	
	public void assertResponseWithData2(ArrayList<HashMap> employeeData){
		Assert.assertEquals(employeeData.get(0).get("company"), "ABC Infotech", "company does not match");
        logger.info("Assertion4:fail");
	}

}
