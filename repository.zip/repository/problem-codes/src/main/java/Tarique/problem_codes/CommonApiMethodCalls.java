package Tarique.problem_codes;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;

public class CommonApiMethodCalls {
	
	private SetupRestAssuredMethods setupRestAssuredMethods= new SetupRestAssuredMethods();
	
	public Response getDataFromUrl(String url) {
        return setupRestAssuredMethods.getApi(url);
    }

}
