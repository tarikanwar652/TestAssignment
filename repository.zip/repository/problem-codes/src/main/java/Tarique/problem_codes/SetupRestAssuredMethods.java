package Tarique.problem_codes;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import static com.jayway.restassured.RestAssured.given;

public class SetupRestAssuredMethods {
	
    public Response response = null;
    
    public static void main(String args[]){
    	//Do nothing for now as this will be useful in a common base setup class  	
    }

	public Response getApi(String url) {
        response = given().when().log().all().get(url).then().extract().response();
        return response;
    }
	
	

}
